sap.ui.define([
	"MIND2PEP_PLANNER/controller/Main"

], function (Controller) {
	"use strict";

	return Controller.extend("dMIND2PEP_PLANNER.controller.FragmentCyclicLeave", {

		onInit: function () {

		}

	});
});